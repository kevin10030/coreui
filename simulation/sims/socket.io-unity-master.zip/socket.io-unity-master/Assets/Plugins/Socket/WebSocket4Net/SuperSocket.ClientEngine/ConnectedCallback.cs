using System.Net.Sockets;

namespace Socket.WebSocket4Net.SuperSocket.ClientEngine {
  public delegate void ConnectedCallback(global::System.Net.Sockets.Socket socket, object state, SocketAsyncEventArgs e);

}