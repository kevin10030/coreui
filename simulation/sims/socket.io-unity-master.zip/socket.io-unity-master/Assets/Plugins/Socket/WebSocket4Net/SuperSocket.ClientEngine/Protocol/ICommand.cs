namespace Socket.WebSocket4Net.SuperSocket.ClientEngine.Protocol {
  public interface ICommand {
    string Name { get; }
  }
}