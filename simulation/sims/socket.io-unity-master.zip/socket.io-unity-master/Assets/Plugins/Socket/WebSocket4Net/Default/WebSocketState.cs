namespace Socket.WebSocket4Net.Default {
  public enum WebSocketState {
    None = -1,
    Connecting = 0,
    Open = 1,
    Closing = 2,
    Closed = 3,
  }
}