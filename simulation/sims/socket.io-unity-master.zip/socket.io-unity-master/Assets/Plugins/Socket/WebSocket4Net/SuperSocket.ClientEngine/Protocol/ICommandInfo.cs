namespace Socket.WebSocket4Net.SuperSocket.ClientEngine.Protocol {
  public interface ICommandInfo {
    string Key { get; }
  }
}