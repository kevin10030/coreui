using System;

namespace Socket.WebSocket4Net.CompilerServices.SuperSocket {
  // [AttributeUsage(AttributeTargets.Method)]
  // public sealed class SuperSocket\u002EClientEngine\u002ECommon35479\u002EExtensionAttribute : Attribute {
  // }
}