namespace Socket.WebSocket4Net.Default {
  public class WebSocketContext {
    
  }
}