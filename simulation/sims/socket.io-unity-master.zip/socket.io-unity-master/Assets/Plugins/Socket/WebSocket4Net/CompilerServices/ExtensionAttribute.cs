using System;

namespace Socket.WebSocket4Net.CompilerServices {
  [AttributeUsage(AttributeTargets.Method)]
  internal sealed class ExtensionAttribute : Attribute {
  }
}