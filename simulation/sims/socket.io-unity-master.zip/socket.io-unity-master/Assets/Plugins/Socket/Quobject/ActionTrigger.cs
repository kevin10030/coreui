namespace Socket.Quobject {
  public delegate void ActionTrigger();
}