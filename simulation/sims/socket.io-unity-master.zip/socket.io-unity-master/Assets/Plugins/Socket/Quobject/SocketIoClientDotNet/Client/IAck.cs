namespace Socket.Quobject.SocketIoClientDotNet.Client {
  public interface IAck {
    void Call(params object[] args);
  }
}