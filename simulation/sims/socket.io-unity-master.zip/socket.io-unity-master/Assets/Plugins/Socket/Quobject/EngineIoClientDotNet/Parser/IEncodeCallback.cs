namespace Socket.Quobject.EngineIoClientDotNet.Parser {
  public interface IEncodeCallback {
    void Call(object data);
  }
}