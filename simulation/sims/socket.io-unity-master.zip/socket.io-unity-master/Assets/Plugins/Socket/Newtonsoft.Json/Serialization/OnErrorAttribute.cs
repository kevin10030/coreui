using System;

namespace Socket.Newtonsoft.Json.Serialization {
  [AttributeUsage(AttributeTargets.Method, Inherited = false)]
  public sealed class OnErrorAttribute : Attribute {
  }
}