namespace Socket.Newtonsoft.Json.Utilities {

  internal enum ParseResult {
    None,
    Success,
    Overflow,
    Invalid,
  }
}