using System.Collections.ObjectModel;

namespace Socket.Newtonsoft.Json {
  public class JsonConverterCollection : Collection<JsonConverter>
  {
  }
}
