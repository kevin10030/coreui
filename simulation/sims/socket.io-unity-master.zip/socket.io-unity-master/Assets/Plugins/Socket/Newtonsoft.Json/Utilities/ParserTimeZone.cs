namespace Socket.Newtonsoft.Json.Utilities {
  internal enum ParserTimeZone {
    Unspecified,
    Utc,
    LocalWestOfUtc,
    LocalEastOfUtc,
  }
}