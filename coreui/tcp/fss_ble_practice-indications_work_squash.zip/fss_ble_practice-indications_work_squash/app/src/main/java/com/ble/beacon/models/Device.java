package com.ble.beacon.models;

import android.bluetooth.BluetoothDevice;

public class Device {
//    public String name = "";
//    public String mac = "";
//    public String uuid = "";
    public BluetoothDevice bleDevice;
    public boolean connectStatus = false;
}
