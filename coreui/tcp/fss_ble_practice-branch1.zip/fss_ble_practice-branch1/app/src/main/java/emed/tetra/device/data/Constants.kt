package emed.tetra.device.data



object Constants {

    @kotlin.jvm.JvmField

    var needFirstConnect: Boolean = false
    const val BASE_URL_PRODUCTION = ""
    const val BASE_URL_DEVELOPMENT = "https://jsonplaceholder.typicode.com/"
    const val DEVICE_NAME = "deviceName"
    const val DEVICE_UUID = "deviceUUID"
    const val DEVICE_MAC = "deviceMAC"
    const val DEVICE_ADDRESS = "A5:12:B9:00:F7:84"
   // public var needFirstConnect = false
    const val BLE_BOND_SUPPORTED = "ble_bond_supported"
    const val PREF_BLE_DEVICE_PIN = "BleDevicePinPreference"

}