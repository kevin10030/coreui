package emed.tetra.device.view.activity;


import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import emed.tetra.device.R;
import emed.tetra.device.app.AppController;
import emed.tetra.device.data.Constants;
import emed.tetra.device.utils.PreferencesUtils;
import emed.tetra.device.view.fragment.DiscoveryFragmentGatt;


public class MainActivity extends AppCompatActivity {

    private final static String TAG = emed.tetra.device.view.activity.MainActivity.class.getSimpleName();

    DiscoveryFragmentGatt discoveryFragment;
    FragmentManager fragmentManager;

    private static final int PERMISSION_REQUEST_COARSE_LOCATION = 1;
    private static final int REQUEST_ENABLE_BT = 1;
    private BluetoothAdapter mBluetoothAdapter;
    private Button btnProceed;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.paring_activity_main);
        btnProceed = findViewById(R.id.btn_proceed);

        btnProceed.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                launchPermissions();
            }
        });


    }


    @Override
    protected void onResume() {
        super.onResume();
    }

    public boolean checkBluetoothAvailability() {
        boolean result = false;

        if (!this.getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            return result;
        }

        if (mBluetoothAdapter==null) {
            final BluetoothManager bluetoothManager =
                    (BluetoothManager) this.getSystemService(Context.BLUETOOTH_SERVICE);
            mBluetoothAdapter = bluetoothManager.getAdapter();
        }

        return !result;
    }



    private void checkBluetooth(){

        if (!checkBluetoothAvailability()){
            Toast.makeText(this,this.getString(R.string.ble_not_available), Toast.LENGTH_LONG);
            return;
        }

        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }else{
            goToSuccess();
        }


    }

    private void launchPermissions(){


        int permission1 = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH);
        int permission2 = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN);
        int permission3 = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION);
        int permission4 = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);



        if (permission1 != PackageManager.PERMISSION_GRANTED
                || permission2 != PackageManager.PERMISSION_GRANTED
                || permission3 != PackageManager.PERMISSION_GRANTED
                || permission4 != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.BLUETOOTH,
                            Manifest.permission.BLUETOOTH_ADMIN,
                            Manifest.permission.ACCESS_COARSE_LOCATION,
                            Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSION_REQUEST_COARSE_LOCATION);
        } else {
            Log.d("DISCOVERING-PERMISSIONS", "Permissions Granted");
          //  Toast.makeText(getActivity(),"Permissions Granted", Toast.LENGTH_SHORT).show();
        }



    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_COARSE_LOCATION: {
                if (grantResults[2] == PackageManager.PERMISSION_GRANTED) {
                    System.out.println("coarse location permission granted");
                  //  Toast.makeText(getActivity(),"coarse location permission granted", Toast.LENGTH_SHORT).show();


                    checkBluetooth();

                } else {

                    goToCancelled();
                }
                return;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK) {
                // Bluetooth was enabled
                goToSuccess();

            } else if (resultCode == RESULT_CANCELED) {
                // Bluetooth was not enabled
                goToCancelled();

            }
        }

    }
    private void goToCancelled(){
        System.exit(0);
    }

    private void goToSuccess(){

        FrameLayout frameLayout = findViewById(R.id.frameContainer);
        frameLayout.setVisibility(View.VISIBLE);
        fragmentManager = getSupportFragmentManager();
        discoveryFragment= new DiscoveryFragmentGatt();
        fragmentManager.beginTransaction().replace(R.id.frameContainer,discoveryFragment).commit();
    }




    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void onClick(View v)
    {
//        switch (v.getId())
//        {
//            case R.id.txt_scan_stop:
//                discoveryFragment.performBleCheck();
//                break;
//            case R.id.txt_buttons:
//
//                break;
//        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if(discoveryFragment.bReceiver != null) unregisterReceiver(discoveryFragment.bReceiver);
        }catch (Exception e){}

        try {
            AppController.connected = false;
            PreferencesUtils.putString(emed.tetra.device.view.activity.MainActivity.this, Constants.DEVICE_MAC, null);
            unbindService(discoveryFragment.mServiceConnection);
            AppController.mBluetoothLeService = null;
        }catch (Exception e){}
    }

}
