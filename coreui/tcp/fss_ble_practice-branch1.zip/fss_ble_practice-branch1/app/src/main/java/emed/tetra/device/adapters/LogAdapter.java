package emed.tetra.device.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import emed.tetra.device.R;

public class LogAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<String> arrayList;
    private TextView txtLogData, name, contactNum;
    public LogAdapter(Context context, ArrayList<String> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }
    @Override
    public int getCount() {
        return arrayList.size();
    }
    @Override
    public Object getItem(int position) {
        return position;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        String data = arrayList.get(position);
        convertView = LayoutInflater.from(context).inflate(R.layout.row, parent, false);
        txtLogData = convertView.findViewById(R.id.txt_Log_data);
        txtLogData.setText(data);

        return convertView;
    }
}