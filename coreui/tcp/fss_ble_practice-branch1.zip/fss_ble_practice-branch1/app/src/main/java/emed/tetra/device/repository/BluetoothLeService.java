/*
 * Copyright (C) 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package emed.tetra.device.repository;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.lang.reflect.Method;
import java.util.List;
import java.util.UUID;

import emed.tetra.device.app.AppController;
import emed.tetra.device.utils.PreferencesUtils;

/**
 * Service for managing connection and data communication with a GATT server hosted on a
 * given Bluetooth LE device.
 */
public class BluetoothLeService extends Service {
    private final static String TAG = emed.tetra.device.repository.BluetoothLeService.class.getSimpleName();

    private BluetoothManager mBluetoothManager;
    public BluetoothAdapter mBluetoothAdapter;
    private String mBluetoothDeviceAddress;
    public BluetoothGatt mBluetoothGatt;
    private int mConnectionState = STATE_DISCONNECTED;

    private static final int STATE_DISCONNECTED = 0;
    private static final int STATE_CONNECTING = 1;
    private static final int STATE_CONNECTED = 2;

    public final static String ACTION_GATT_CONNECTED =
            "com.example.bluetooth.le.ACTION_GATT_CONNECTED";
    public final static String ACTION_GATT_DISCONNECTED =
            "com.example.bluetooth.le.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED =
            "com.example.bluetooth.le.ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_DATA_AVAILABLE =
            "com.example.bluetooth.le.ACTION_DATA_AVAILABLE";
    public final static String EXTRA_DATA =
            "com.example.bluetooth.le.EXTRA_DATA";


    private final Integer UUID_INTEGER = 0x2902;
    private String UUID_STR = "a512b914-9f78-4809-a5d9-31556dc20c00";


    AppCompatActivity mActivity;
    private String mConnectorPin;
    private static final int PAIRING_VARIANT_CONSENT = 3;

    private static final int GATT_CONNECTION_TIMEOUT = 0x08;
    private static final int GATT_REMOTE_DEVICE_ERROR = 0x13;
    private static final int GATT_LOCAL_HOST_ERROR = 0x16;
    private static final int GATT_INTERNAL_ERROR = 0x81;
    private static final int GATT_ERROR = 0x85;

    private static final int SERVICES_DISCOVERY_DELAY = 100;


    public void showToast(final String msg)
    {
        mActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(mActivity, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }


    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            String intentAction;
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    Log.i(TAG, "Connected to GATT server.");
                    showToast("Connected to GATT server.");
                     if (gatt.getDevice().getBondState() == BluetoothDevice.BOND_BONDED) {
                        showToast("Bond State is BONDED.");
                        try {
                            Thread.sleep(SERVICES_DISCOVERY_DELAY);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        intentAction = ACTION_GATT_CONNECTED;
                        mConnectionState = STATE_CONNECTED;
                        broadcastUpdate(intentAction);

                        mBluetoothGatt.discoverServices();
                    } else {
                        Log.i(TAG, "Waiting for device pairing...");
                        showToast("Waiting for device pairing...");

                        pairDevice(gatt.getDevice());
                    }

                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    Log.i(TAG, "Device disconnected");
                    closeConnection(false);
                }

            } else if (status == GATT_CONNECTION_TIMEOUT) {
                Log.w(TAG, "Remote device not responding");
                showToast("Connection error: remote device not responding");
                closeConnection(true);

            } else if (status == GATT_REMOTE_DEVICE_ERROR) {
                Log.w(TAG, "Remote device terminate the connection");
                showToast("Communication error: remote device closed connection");
                PreferencesUtils.setBlePin(gatt.getDevice().getAddress(), null);
                closeConnection(true);

            } else if (status == GATT_LOCAL_HOST_ERROR) {
                Log.w(TAG, "Local host terminate the connection");
                showToast("Connection error: local host terminated connection");
                closeConnection(true);

            } else if (status == GATT_INTERNAL_ERROR || status == GATT_ERROR) {
                Log.w(TAG, "Remote device not working");
                showToast("Connection error: communication service not working");

                if (gatt.getDevice().getBondState() == BluetoothDevice.BOND_BONDED)
                    PreferencesUtils.setBleBondSupported(false);
                closeConnection(true);
            }


        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {

            if (status == BluetoothGatt.GATT_SUCCESS) {


                System.out.println("na1: onServicesDiscovered:");
                List<BluetoothGattService> gattServices = gatt.getServices();
                for (BluetoothGattService gattService : gattServices) {



                    List<BluetoothGattCharacteristic> characteristics = gattService.getCharacteristics();
                    for (BluetoothGattCharacteristic characteristic : characteristics) {
                        String uuid = characteristic.getUuid().toString() ;

                        // I am searching the device to find the UUID
                        if (characteristic.getUuid().toString().equals(UUID_STR)) {
                            System.out.println("na1:  got it, uuid" );

                            enableSensor(gatt, characteristic);

                        }

                    }
                }

                broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);

            } else {
                Log.w(TAG, "onServicesDiscovered received: " + status);
                showToast("Connection error: communication service not supported");
                closeConnection(true);
            }
        }


        private void enableSensor(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            gatt.readCharacteristic(characteristic);
        }


        private void setNotifySensor(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            gatt.setCharacteristicNotification(characteristic, true);
            BluetoothGattDescriptor descriptor = characteristic.getDescriptor(convertFromInteger(UUID_INTEGER));
            if(descriptor != null) {
                descriptor.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
                gatt.writeDescriptor(descriptor);
            }
        }


        public UUID convertFromInteger(int i) {
            final long MSB = 0x0000000000001000L;
            final long LSB = 0x800000805f9b34fbL;
            long value = i & 0xFFFFFFFF;
            return new UUID(MSB | (value << 32), LSB);
        }



        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {

            Log.i(TAG, String.format("Device mtu changed, status %d, mtu %d", status, mtu));

            if (status != BluetoothGatt.GATT_SUCCESS) {
                showToast("Connection error: communication service not supported");
                closeConnection(true);
                return;
            }

            broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic,
                                         int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
            }

            setNotifySensor(gatt, characteristic);
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt,
                                            BluetoothGattCharacteristic characteristic) {
            broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorWrite(gatt, descriptor, status);

            List<BluetoothGattService> gattServices = gatt.getServices();
            for (BluetoothGattService gattService : gattServices) {
                List<BluetoothGattCharacteristic> characteristics = gattService.getCharacteristics();
                for (BluetoothGattCharacteristic characteristic : characteristics) {
                    if (characteristic.getUuid().toString().equals(UUID_STR)) {
                        enableSensor(gatt, characteristic);
                    }
                }
            }
        }


    };

    private void broadcastUpdate(final String action) {
        final Intent intent = new Intent(action);
        sendBroadcast(intent);
    }

    private void broadcastUpdate(final String action,
                                 final BluetoothGattCharacteristic characteristic) {
        final Intent intent = new Intent(action);

        // For all other profiles, writes the data formatted in HEX.
        final byte[] data = characteristic.getValue();
        if (data != null && data.length > 0) {
            final StringBuilder stringBuilder = new StringBuilder(data.length);
            for(byte byteChar : data) {
                if(byteChar != 0)
                    stringBuilder.append(String.format("%c", byteChar));
            }
            intent.putExtra(EXTRA_DATA, stringBuilder.toString());
        }



        sendBroadcast(intent);
    }

    public class LocalBinder extends Binder {
        public emed.tetra.device.repository.BluetoothLeService getService() {
            return emed.tetra.device.repository.BluetoothLeService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {

        closeConnection(false);
        try {
            AppController.getContext().unregisterReceiver(mActionReceiver);
        }catch (Exception e){}
        return super.onUnbind(intent);
    }

    private final IBinder mBinder = new LocalBinder();

    public boolean initialize(AppCompatActivity activity) {
        mActivity = activity;

        setFilter(AppController.getContext());

        if (mBluetoothManager == null) {
            mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null) {
                Log.e(TAG, "Unable to initialize BluetoothManager.");
                return false;
            }
        }

        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null) {
            Log.e(TAG, "Unable to obtain a BluetoothAdapter.");
            return false;
        }

        return true;
    }


    private final BroadcastReceiver mActionReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {

            Log.i(TAG, String.format("Received system event: action %s", intent.getAction()));
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

            if (BluetoothDevice.ACTION_PAIRING_REQUEST.equals(intent.getAction())) {
                int var = intent.getIntExtra(BluetoothDevice.EXTRA_PAIRING_VARIANT, BluetoothDevice.ERROR);


                Log.i(TAG, String.format("Using app functionality to pair to device, variant: %d", var));
                showToast(String.format("Using app functionality to pair to device, variant: %d", var));
                if (var == BluetoothDevice.PAIRING_VARIANT_PASSKEY_CONFIRMATION || var == PAIRING_VARIANT_CONSENT) {
                    Log.i(TAG, "Trying to confirm pairing...");
                    showToast("Trying to confirm pairing...");
                    try {
                        device.getClass().getMethod("setPairingConfirmation", boolean.class).invoke(device, true);
                        abortBroadcast();
                    } catch (Exception e) { // при провале системный запрос уйдёт пользователю
                        Log.w(TAG, "Pairing auto-confirmation failed");
                        e.printStackTrace();
                     }

                } else if (var == BluetoothDevice.PAIRING_VARIANT_PIN) {
                    Log.i(TAG, "Device PIN requested");
                    showToast("Device PIN requested");
                    String pin = PreferencesUtils.getBlePin(device.getAddress());
                    if (pin != null) {
                        Log.i(TAG, "Saved PIN sent");
                        device.setPin(pin.getBytes());
                    }
                    abortBroadcast();
                }

            } else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(intent.getAction())) {
                final int state = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.ERROR);
                Log.i(TAG, String.format("Device bond state changed, new state: %d", state));
                showToast(String.format("Device bond state changed, new state: %d", state));
                if (state == BluetoothDevice.BOND_BONDED) {
                    if (mConnectorPin != null) {
                        PreferencesUtils.setBlePin(device.getAddress(), mConnectorPin);
                        mConnectorPin = null;
                        Log.i(TAG, "Device PIN saved");
                    }
                    try {
                        Thread.sleep(SERVICES_DISCOVERY_DELAY);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    String intentAction = ACTION_GATT_CONNECTED;
                    mConnectionState = STATE_CONNECTED;
                    broadcastUpdate(intentAction);

                    mBluetoothGatt.discoverServices();
                }
            }
        }
    };

    private void setFilter(Context ctx) {
        IntentFilter filter = new IntentFilter();
        filter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY - 1);
        filter.addAction(BluetoothDevice.ACTION_PAIRING_REQUEST);
        filter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        ctx.registerReceiver(mActionReceiver, filter);
    }


    public boolean connect(final String address) {
        if (mBluetoothAdapter == null || address == null) {
            Log.w(TAG, "BluetoothAdapter not initialized or unspecified address.");
            return false;
        }

        final BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        if (device == null) {
            Log.w(TAG, "Device not found.  Unable to connect.");
            showToast("Device not found.  Unable to connect.");
            return false;
        }


        int bondState = device.getBondState();
        Log.i(TAG, String.format("Device bond state: %d", bondState));
        showToast(String.format("Device bond state: %d", bondState));

        if (!PreferencesUtils.isBleBondSupported() && bondState != BluetoothDevice.BOND_NONE) {
            unbindDevice(device);
        }

        Log.d(TAG, "Trying to create a new connection. "+address);
        showToast("Trying to create a new connection. "+address);


        mBluetoothGatt = device.connectGatt(this, false, mGattCallback);
        mBluetoothDeviceAddress = address;
        mConnectionState = STATE_CONNECTING;

        return true;
    }


    public void disconnect() {

        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            return;
        }
        mBluetoothGatt.disconnect();
    }


    public void closeConnection(boolean unbind) {
        if (mBluetoothGatt == null) {
            return;
        }

        try {
            BluetoothDevice device = mBluetoothGatt.getDevice();
            if (!PreferencesUtils.isBleBondSupported() || unbind)
                unbindDevice(device);

            disconnect();
            mBluetoothGatt.close();
            mBluetoothGatt = null;
            mBluetoothDeviceAddress = null;
        }catch (Exception e){}

        String intentAction = ACTION_GATT_DISCONNECTED;
        mConnectionState = STATE_DISCONNECTED;
        Log.i(TAG, "Disconnected from GATT server.");
        broadcastUpdate(intentAction);
    }


    public List<BluetoothGattService> getSupportedGattServices() {
        if (mBluetoothGatt == null) return null;

        return mBluetoothGatt.getServices();
    }


    public void setPin(String pin, boolean remember) {
        Log.i(TAG, "Device PIN entered");
        if (mBluetoothGatt != null) {
            mBluetoothGatt.getDevice().setPin(pin.getBytes());
            mConnectorPin = remember ? pin : null;
        }
    }

    private void pairDevice(BluetoothDevice device) {

        showToast("Start Pairing... with: " + device.getName());
        try {
            Log.d(TAG, "Start Pairing... with: " + device.getName());
            device.createBond();
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
    }

    private void unbindDevice(BluetoothDevice device) {
        Log.i(TAG, "Removing device bond...");
        try {
            Method m = device.getClass().getMethod("removeBond", (Class[]) null);
            m.invoke(device, (Object[]) null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.i(TAG, "Device bond removed");
        showToast("Device bond removed");
    }

}
