package emed.tetra.device.repository


import emed.tetra.device.network.RetrofitModule
import emed.tetra.device.network.ServiceApi
import emed.tetra.device.network.response.PostResponse
import io.reactivex.Flowable


class RemoteRepository {

    private val serviceApi: ServiceApi = RetrofitModule.instance!!.getService()

    fun getPosts(): Flowable<PostResponse> {
        return serviceApi.getPosts()
    }
}