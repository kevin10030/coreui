package emed.tetra.device.adapters;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

import emed.tetra.device.R;
import emed.tetra.device.app.AppController;
import emed.tetra.device.data.Constants;
import emed.tetra.device.data.Device;
import emed.tetra.device.utils.PreferencesUtils;

public class LeDeviceListAdapter extends BaseAdapter {
    private ArrayList<Device> mLeDevices;
    private Context context;


    static class ViewHolder {
        TextView deviceName;
        Button btnPair;
    }


    public LeDeviceListAdapter(Context ctx, ArrayList<Device> devices ) {
        super();

        mLeDevices = devices;
        context = ctx;

    }

    public void addDevice(Device device) {

        for(Device db:mLeDevices) {
            if(device.bleDevice.getAddress().equals(db.bleDevice.getAddress())) return;
        }
        mLeDevices.add(device);
    }

    public Device getDevice(int position) {
        return mLeDevices.get(position);
    }

    public void clear() {
        mLeDevices.clear();
    }

    @Override
    public int getCount() {
        return mLeDevices.size();
    }

    @Override
    public Object getItem(int i) {
        return mLeDevices.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        ViewHolder viewHolder;
        LayoutInflater mInflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (view == null) {
            view = mInflator.inflate(R.layout.device_item, null);
            viewHolder = new ViewHolder();
            viewHolder.deviceName = (TextView) view.findViewById(R.id.tvName);
            viewHolder.btnPair = view.findViewById(R.id.btnPair);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }

        final Device device = mLeDevices.get(i);
        String deviceName = device.bleDevice.getName();
        if (deviceName != null && deviceName.length() > 0)
            viewHolder.deviceName.setText(deviceName+"\n"+device.bleDevice.getAddress());
        else
            viewHolder.deviceName.setText("unknown device" +"\n"+device.bleDevice.getAddress());

        viewHolder.btnPair.setText("Pair");

        viewHolder.btnPair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (device == null) return;

                if(device.connectStatus == true) {

                    AppController.mBluetoothLeService.connect(Constants.DEVICE_ADDRESS);
                    Constants.needFirstConnect = false;
                    mLeDevices.clear();
                    notifyDataSetChanged();

                } else {

                    PreferencesUtils.putString(context,Constants.DEVICE_MAC,device.bleDevice.getAddress());
                    AppController.mBluetoothLeService.connect(device.bleDevice.getAddress());
                }
            }
        });
        return view;
    }
}