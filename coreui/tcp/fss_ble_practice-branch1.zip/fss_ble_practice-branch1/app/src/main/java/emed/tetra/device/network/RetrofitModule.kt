package emed.tetra.device.network

import android.app.Application
import com.google.gson.FieldNamingPolicy
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import emed.tetra.device.data.Constants
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import okhttp3.*
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory


import java.io.File
import java.util.concurrent.TimeUnit

class RetrofitModule private constructor(private val context: Application) {
    private lateinit var cache: Cache
    private lateinit var gson: Gson
    private lateinit var okHttpClient: OkHttpClient
    private lateinit var retrofit: Retrofit
    private lateinit var service: ServiceApi

    private fun provideCache() {
        val cacheSize = (10 * 1024 * 1024).toLong()
        try {
            val myDir = File(context.cacheDir, "response")
            myDir.mkdir()
            cache = Cache(myDir, cacheSize)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun provideGson() {
        val gsonBuilder = GsonBuilder()
        gsonBuilder.setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE)
        gson = gsonBuilder.create()
    }

    private fun provideOkhttpClient() {
        val interceptor = HttpLoggingInterceptor()
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY)
        okHttpClient = OkHttpClient.Builder()
            .writeTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .addInterceptor(interceptor)
            .build()
    }

    private fun provideRetrofit() {
        retrofit = Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create(gson))
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .baseUrl(Constants.BASE_URL_DEVELOPMENT)
            .client(okHttpClient)
            .build()
    }

    private fun provideService() {
        service = retrofit.create(ServiceApi::class.java)
    }

    companion object {
        var instance: RetrofitModule? = null

        fun initialize(context: Application) {
            instance = RetrofitModule(context)
        }
    }

    fun getService(): ServiceApi{
        return service
    }

    init {
        provideCache()
        provideGson()
        provideOkhttpClient()
        provideRetrofit()
        provideService()
    }
}