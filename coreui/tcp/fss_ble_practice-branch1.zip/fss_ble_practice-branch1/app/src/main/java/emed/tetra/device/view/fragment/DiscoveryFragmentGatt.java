package emed.tetra.device.view.fragment;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import emed.tetra.device.R;
import emed.tetra.device.adapters.DeviceFoundAdapter;
import emed.tetra.device.adapters.LeDeviceListAdapter;
import emed.tetra.device.adapters.LogAdapter;
import emed.tetra.device.app.AppController;
import emed.tetra.device.data.Constants;
import emed.tetra.device.data.Device;
import emed.tetra.device.repository.BluetoothLeService;
import emed.tetra.device.utils.PreferencesUtils;
import emed.tetra.device.view.activity.MainActivity;


public class DiscoveryFragmentGatt extends Fragment {

    private static final String TAG = emed.tetra.device.view.fragment.DiscoveryFragmentGatt.class.getSimpleName();
    View view;

    private ListView listView;
    private TextView txtMenu;
    ProgressBar progressBar;
    private LeDeviceListAdapter mLeDeviceListAdapter;
    private DeviceFoundAdapter deviceFoundAdapter;
    private LogAdapter logAdapter;
    private static ArrayList<String> arrayList;

    private BluetoothAdapter mBluetoothAdapter;
    private Handler mHandler;

    private static final int PERMISSION_REQUEST_COARSE_LOCATION = 1;
    private static final int REQUEST_ENABLE_BT = 1;



    private boolean pendingRequestEnableBt = false;
    public BroadcastReceiver bReceiver;


    private void assignLogAdapter(String dt){
        arrayList.add(dt);
        logAdapter = new LogAdapter(getActivity(), arrayList);
        listView.setAdapter(logAdapter);
        logAdapter.notifyDataSetChanged();

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_home, container, false);

        mHandler = new Handler();
        listView = view.findViewById(R.id.list_device);
        progressBar = view.findViewById(R.id.progressBar);

        ArrayList<Device> devices = new ArrayList<Device>();
        mLeDeviceListAdapter = new LeDeviceListAdapter(getActivity(),devices);
        listView.setAdapter(mLeDeviceListAdapter);
        arrayList = new ArrayList<String>();
        checkBluetoothAvailability();

        requestEnableBluetooth();

        int permission1 = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.BLUETOOTH);
        int permission2 = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.BLUETOOTH_ADMIN);
        int permission3 = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION);
        int permission4 = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION);



        if (permission1 != PackageManager.PERMISSION_GRANTED
                || permission2 != PackageManager.PERMISSION_GRANTED
                || permission3 != PackageManager.PERMISSION_GRANTED
                || permission4 != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{
                            Manifest.permission.BLUETOOTH,
                            Manifest.permission.BLUETOOTH_ADMIN,
                            Manifest.permission.ACCESS_COARSE_LOCATION,
                            Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSION_REQUEST_COARSE_LOCATION);
        } else {
            Log.d("DISCOVERING-PERMISSIONS", "Permissions Granted");
            Toast.makeText(getActivity(),"Permissions Granted", Toast.LENGTH_SHORT).show();
        }

        String mBluetoothDeviceAddress = PreferencesUtils.getString(getActivity(), Constants.DEVICE_MAC, null);
        if(mBluetoothDeviceAddress != null)
            Constants.needFirstConnect = true;

        Intent gattServiceIntent = new Intent(getActivity(), BluetoothLeService.class);
        getActivity().bindService(gattServiceIntent, mServiceConnection, getActivity().BIND_AUTO_CREATE);


        performBleCheck();


        return view;
    }





    private void launchDevicesFoundFromSearch(List<String> deviceList) {

        Dialog dialog = new Dialog(getActivity(), android.R.style.Theme_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.search_device);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        DeviceFoundAdapter deviceFoundAdapter = new DeviceFoundAdapter(getActivity(), deviceList);
        RecyclerView recyclerView =  dialog.findViewById(R.id.rv_devices_found);
        recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL));


        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        recyclerView.setAdapter(deviceFoundAdapter);
        deviceFoundAdapter.notifyDataSetChanged();

        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setLayout(1000, 1400); //Controlling width and height.

        dialog.show();

    }

    


    private void launchDeviceFoundPopUp() {

        Dialog dialog = new Dialog(getActivity(), android.R.style.Theme_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.search_device);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        RecyclerView recyclerView =  dialog.findViewById(R.id.rv_devices_found);


        arrayList.add("dt");
        deviceFoundAdapter = new DeviceFoundAdapter(getActivity(), arrayList);
        recyclerView.setAdapter(deviceFoundAdapter);
        deviceFoundAdapter.notifyDataSetChanged();





        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setLayout(1000, 1400); //Controlling width and height.

        dialog.show();

    }




    private void launchDeviceTurnedOff() {

        Dialog dialog = new Dialog(getActivity(), android.R.style.Theme_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.device_turned_off);
        dialog.setCanceledOnTouchOutside(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Button btnTurnOnBl = (Button) dialog.findViewById(R.id.btn_turn_on_bl);
        Button btnCancelId = (Button) dialog.findViewById(R.id.btn_cancel);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.getWindow().setLayout(1000, 600);

        btnTurnOnBl.setOnClickListener(v -> {
            // Close dialog

            dialog.dismiss();

        });



        btnCancelId.setOnClickListener(v -> {
            // Close dialog

            dialog.dismiss();

        });





        dialog.show();

    }









     public final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            AppController.mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
            if (!AppController.mBluetoothLeService.initialize((MainActivity)getActivity())) {
                Log.e(TAG, "Unable to initialize Bluetooth");
                Toast.makeText(getActivity(), "Unable to initialize Bluetooth", Toast.LENGTH_SHORT).show();
                //finish();
                return;
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            AppController.mBluetoothLeService = null;
        }
    };

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_COARSE_LOCATION: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    System.out.println("coarse location permission granted");
                    Toast.makeText(getActivity(),"coarse location permission granted", Toast.LENGTH_SHORT).show();
                } else {
                }
                return;
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!checkBluetoothAvailability()) return;

        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }

        getActivity().registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
    }

    @Override
    public void onPause() {
        super.onPause();
        if (!checkBluetoothAvailability()) return;

        getActivity().unregisterReceiver(mGattUpdateReceiver);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if(requestCode ==  REQUEST_ENABLE_BT) pendingRequestEnableBt = false;
        if (requestCode == REQUEST_ENABLE_BT && resultCode == Activity.RESULT_CANCELED) {
            return;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    public boolean checkBluetoothAvailability() {
        boolean result = false;

        if (!getActivity().getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            return result;
        }

        if (mBluetoothAdapter==null) {
            final BluetoothManager bluetoothManager =
                    (BluetoothManager) getActivity().getSystemService(Context.BLUETOOTH_SERVICE);
            mBluetoothAdapter = bluetoothManager.getAdapter();
        }

        return !result;
    }



    private void updateConnectionState(final int resourceId) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {

                String mBluetoothDeviceAddress = PreferencesUtils.getString(getActivity(),Constants.DEVICE_MAC, null);
                Log.d(TAG, "connected device address:"+mBluetoothDeviceAddress);
                for(int i=0;i<mLeDeviceListAdapter.getCount();i++) {
                    Log.d(TAG, "device:"+i+" address:"+mLeDeviceListAdapter.getDevice(i).bleDevice.getAddress());
                    if(mBluetoothDeviceAddress!=null && mLeDeviceListAdapter.getDevice(i).bleDevice.getAddress().equals(mBluetoothDeviceAddress)) {
                        mLeDeviceListAdapter.getDevice(i).connectStatus = true;
                        Log.d(TAG, "connected device:"+i+" address:"+mBluetoothDeviceAddress);
                    } else mLeDeviceListAdapter.getDevice(i).connectStatus = false;
                }
                mLeDeviceListAdapter.notifyDataSetChanged();

                progressBar.setVisibility(View.GONE);
                if(resourceId == 0){

                    Toast.makeText(getActivity(),"Device Paired Successfully",Toast.LENGTH_SHORT).show();
                } else {

                    Toast.makeText(getActivity(),"Device paired unsuccessfully",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    public final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
                AppController.connected = true;
                updateConnectionState(0);
            } else if (BluetoothLeService.ACTION_GATT_DISCONNECTED.equals(action)) {
                AppController.connected = false;
                updateConnectionState(1);
            } else if (BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED.equals(action)) {

                progressBar.setVisibility(View.GONE);
                AppController.characteristic = null;
                List<BluetoothGattService> gattServices = AppController.mBluetoothLeService.getSupportedGattServices();
                if (gattServices == null) return;
                for (BluetoothGattService gattService : gattServices) {
                    List<BluetoothGattCharacteristic> gattCharacteristics =
                            gattService.getCharacteristics();
                    for (BluetoothGattCharacteristic gattCharacteristic : gattCharacteristics) {

                        final int charaProp = gattCharacteristic.getProperties();
                        if (((charaProp & BluetoothGattCharacteristic.PROPERTY_WRITE) |
                                (charaProp & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) > 0) {
                            AppController.characteristic = gattCharacteristic;

                        }

                    }
                }

            } else if(BluetoothLeService.ACTION_DATA_AVAILABLE.equals(action)) {
                final String data = intent.getStringExtra(emed.tetra.device.repository.BluetoothLeService.EXTRA_DATA);
                assignLogAdapter(data);

            }




        }
    };

    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        return intentFilter;
    }


    private void requestEnableBluetooth() {

        if (BluetoothAdapter.getDefaultAdapter()!=null && !isBluetoothAdapterDiscovering() && !pendingRequestEnableBt) {
            pendingRequestEnableBt = true;
        }
    }

    private boolean isBluetoothAdapterDiscovering() {
        return getBluetoothAdapter().isDiscovering();
    }

    private BluetoothAdapter getBluetoothAdapter() {
        return BluetoothAdapter.getDefaultAdapter();
    }

    public void performBleCheck() {

        if (!checkBluetoothAvailability()) {
            Toast.makeText(getActivity(), "Please turn bluetooth on. Bluetooth is not available", Toast.LENGTH_SHORT).show();
            return;
        }
        mLeDeviceListAdapter.clear();
        mLeDeviceListAdapter.notifyDataSetChanged();




        //if there is already connected device,
        if(AppController.connected) {
            Device device = new Device();
            String mBluetoothDeviceAddress = PreferencesUtils.getString(getActivity(), Constants.DEVICE_ADDRESS, null);
            device.bleDevice= mBluetoothAdapter.getRemoteDevice(mBluetoothDeviceAddress);
            try {
                if(Constants.needFirstConnect) {

                    Log.e("MainActivity", "Address:" + mBluetoothDeviceAddress);
                    if (mBluetoothDeviceAddress != null && AppController.mBluetoothLeService != null) {
                        AppController.mBluetoothLeService.connect(mBluetoothDeviceAddress);
                        Constants.needFirstConnect = false;
                        Log.e("MainActivity", "first connect(service connected):" + mBluetoothDeviceAddress);
                    }
                } else device.connectStatus = true;
            }catch (Exception e){ }

            mLeDeviceListAdapter.addDevice(device);
            mLeDeviceListAdapter.notifyDataSetChanged();
        }


        bReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if(BluetoothDevice.ACTION_FOUND.equals(intent.getAction())) {
                    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    Log.e("na1: ", ""+ device.toString());
                    Device deviceModel = new Device();
                    deviceModel.bleDevice = device;
                    String mBluetoothDeviceAddress = PreferencesUtils.getString(getActivity(),Constants.DEVICE_MAC, null);
                    if(device!=null && device.getAddress().equals(Constants.DEVICE_ADDRESS)) {
                        try {
                            if(Constants.needFirstConnect) {

                                Log.e("MainActivity", "Address:" + mBluetoothDeviceAddress);
                                if (mBluetoothDeviceAddress != null && AppController.mBluetoothLeService != null) {
                                    Constants.needFirstConnect = false;
                                    Log.e("MainActivity", "first connect(service connected):" + mBluetoothDeviceAddress);
                                }
                            } else {
                                deviceModel.connectStatus = true;
                            }
                        }catch (Exception e){ }

                        Log.d(TAG, " Discovered Device [Name:  " + device.getName() + ", MAC Address: " + device.getAddress());
                        progressBar.setVisibility(View.GONE);
                        mLeDeviceListAdapter.addDevice(deviceModel);
                        mLeDeviceListAdapter.notifyDataSetChanged();
                    }


                } else if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(intent.getAction()))
                {
                    progressBar.setVisibility(View.GONE);
                    mLeDeviceListAdapter.notifyDataSetChanged();
                }
            }
        };

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothDevice.ACTION_FOUND);
        intentFilter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        intentFilter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        getActivity().registerReceiver(bReceiver, intentFilter);


        Log.d(TAG, "Looking up (Discovering) for more bluetooth devices.. ");
        if(getBluetoothAdapter().isDiscovering())
            getBluetoothAdapter().cancelDiscovery();

        getBluetoothAdapter().startDiscovery();

        progressBar.setVisibility(View.VISIBLE);
    }
}
