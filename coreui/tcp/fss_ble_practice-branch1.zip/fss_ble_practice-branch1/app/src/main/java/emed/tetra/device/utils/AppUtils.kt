package emed.tetra.device.utils

import android.os.Build
import android.text.Html
import android.widget.TextView
import androidx.annotation.StringRes

class AppUtils {

}