package emed.tetra.device.data;

import android.bluetooth.BluetoothDevice;

public class Device {
    public BluetoothDevice bleDevice;
    public boolean connectStatus = false;
}
