package emed.tetra.device.network

import emed.tetra.device.network.response.PostResponse
import io.reactivex.Flowable
import retrofit2.http.*

@JvmSuppressWildcards
interface ServiceApi {

    @GET("posts/1")
    fun getPosts(): Flowable<PostResponse>

}