package emed.tetra.device.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import emed.tetra.device.network.response.PostResponse
import emed.tetra.device.repository.RemoteRepository
import emed.tetra.device.utils.BaseViewModel
import emed.tetra.device.utils.ViewState
import retrofit2.HttpException


class MainViewModel: BaseViewModel() {

    fun getPosts(): LiveData<ViewState<PostResponse>> {
        val posts = MutableLiveData<ViewState<PostResponse>>()










        return posts
    }

    private fun handleError(throwable: Throwable): String {
        return if (throwable is HttpException) {
            when (throwable.code()) {
                400 -> {
                    "Something went wrong"
                }
                403 -> {
                    "You should login"
                }
                500 -> {
                    "Something went wrong"
                }
                else -> {
                    throwable.message!!
                }
            }
        } else {
            throwable.message!!
        }
    }
}